import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Random;

public class SnakeGame extends JPanel implements ActionListener {
    private final int BOX_SIZE = 20;
    private final int WIDTH = 30;
    private final int HEIGHT = 20;
    private final int DELAY = 150;

    private ArrayList<Point> snake;
    private Point food;
    private int direction;
    private boolean inGame;
    private Timer timer;

    public SnakeGame() {
        initGame();
    }

    private void initGame() {
        snake = new ArrayList<>();
        snake.add(new Point(5, 5)); // Initial position of the snake
        food = new Point(15, 15); // Initial position of the food
        direction = KeyEvent.VK_RIGHT; // Initial direction
        inGame = true;

        timer = new Timer(DELAY, this);
        timer.start();

        setPreferredSize(new Dimension(WIDTH * BOX_SIZE, HEIGHT * BOX_SIZE));
        setBackground(Color.BLACK);
        setFocusable(true);
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                if ((key == KeyEvent.VK_LEFT || key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_UP || key == KeyEvent.VK_DOWN) && Math.abs(key - direction) != 2) {
                    direction = key;
                }
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (inGame) {
            // Draw snake
            g.setColor(Color.GREEN);
            for (Point p : snake) {
                g.fillRect(p.x * BOX_SIZE, p.y * BOX_SIZE, BOX_SIZE, BOX_SIZE);
            }

            // Draw food
            g.setColor(Color.RED);
            g.fillRect(food.x * BOX_SIZE, food.y * BOX_SIZE, BOX_SIZE, BOX_SIZE);
        } else {
            gameOver(g);
        }
    }

    private void move() {
        // Move the snake
        Point head = snake.get(0);
        Point newHead;
        switch (direction) {
            case KeyEvent.VK_LEFT:
                newHead = new Point(head.x - 1, head.y);
                break;
            case KeyEvent.VK_RIGHT:
                newHead = new Point(head.x + 1, head.y);
                break;
            case KeyEvent.VK_UP:
                newHead = new Point(head.x, head.y - 1);
                break;
            case KeyEvent.VK_DOWN:
                newHead = new Point(head.x, head.y + 1);
                break;
            default:
                newHead = head;
        }

        // Check for collision with wall or itself
        if (newHead.x < 0 || newHead.x >= WIDTH || newHead.y < 0 || newHead.y >= HEIGHT || snake.contains(newHead)) {
            inGame = false;
            timer.stop();
        } else {
            snake.add(0, newHead);
            if (newHead.equals(food)) {
                // Generate new food
                food = generateFood();
            } else {
                snake.remove(snake.size() - 1);
            }
        }
    }

    private Point generateFood() {
        Random random = new Random();
        int x = random.nextInt(WIDTH);
        int y = random.nextInt(HEIGHT);
        while (snake.contains(new Point(x, y))) {
            x = random.nextInt(WIDTH);
            y = random.nextInt(HEIGHT);
        }
        return new Point(x, y);
    }

    private void gameOver(Graphics g) {
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 24));
        FontMetrics metrics = getFontMetrics(g.getFont());
        String msg = "Game Over";
        g.drawString(msg, (WIDTH * BOX_SIZE - metrics.stringWidth(msg)) / 2, HEIGHT * BOX_SIZE / 2);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (inGame) {
            move();
        }
        repaint();
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Snake Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(new SnakeGame());
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
